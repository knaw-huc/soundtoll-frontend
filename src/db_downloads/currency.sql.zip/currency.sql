-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Gegenereerd op: 16 sep 2021 om 14:33
-- Serverversie: 5.5.53
-- PHP-versie: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `soundtoll`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `currency`
--

CREATE TABLE `currency` (
  `Name` varchar(75) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `short` varchar(5) NOT NULL,
  `URL` varchar(75) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Gegevens worden geëxporteerd voor tabel `currency`
--

INSERT INTO `currency` (`Name`, `short`, `URL`) VALUES
('', '?', ''),
('Albertus Daler', 'AD', 'http://www.danskmoent.dk/albert.htm'),
('Albus', 'Al', 'http://www.danskmoent.dk/c2njj.htm'),
('Amme', 'Am', ''),
('Cruzado', 'Cr', ''),
('Daler', 'Da', 'http://www.danskmoent.dk/1daler.htm'),
('Daler Realer', 'De', 'http://www.danskmoent.dk/piaster.htm'),
('Dobelt Dobelt Dukat', 'Dd', ''),
('Dobelt Dobelt Pystoletter', 'Do', 'https://en.wikipedia.org/wiki/Pistole'),
('Dobelt Keiser Gulden', 'DK', ''),
('Dobelt Pystoletter', 'DP', 'https://en.wikipedia.org/wiki/Pistole'),
('Doppelt Philipus Gulden', 'Dp', ''),
('Doppelte Dukater', 'DD', 'http://www.danskmoent.dk/2dukat.htm'),
('Doppelte Prince Gulden', 'Dg', ''),
('Doppelte Rosenobel', 'DR', 'http://www.danskmoent.dk/2nobel.htm'),
('Dukat', 'Du', 'http://www.danskmoent.dk/1dukat.htm'),
('Enckel Pystoletter', 'EP', 'https://en.wikipedia.org/wiki/Pistole'),
('Engelot', 'En', 'http://www.danskmoent.dk/engelot.htm'),
('Enkel Keiser Gulden', 'EK', ''),
('Frands Krone', 'FK', ''),
('Gamle Engelot', 'GE', 'http://www.danskmoent.dk/engelot.htm'),
('Gammelt Daler', 'GD', ''),
('Golden Løwe', 'GL', 'http://www.danskmoent.dk/gyldlove.htm'),
('Groser', 'Gr', 'http://www.danskmoent.dk/gros.htm'),
('GuldGylden', 'GG', 'http://www.danskmoent.dk/guldgyld.htm'),
('Gylden', 'Gy', 'http://www.danskmoent.dk/guldgyld.htm'),
('Halve Dukat', 'HD', ''),
('Halve Pistoletter', 'HP', 'https://en.wikipedia.org/wiki/Pistole'),
('Henricus Nobel', 'HN', 'http://wiki.muntenenpapiergeld.nl/index.php?title=Henricus_nobel'),
('Hollands Rosenobel', 'HR', 'https://nl.wikipedia.org/wiki/Nobel_(munt)'),
('Hoornse Gulden', 'HG', ''),
('Kaaber lests', 'Kl', ''),
('Keyser Gulden', 'KG', ''),
('Kongens Rosenobel', 'Ko', 'http://www.danskmoent.dk/1nobel.htm'),
('Krone', 'Kr', 'http://www.danskmoent.dk/1krone.htm'),
('Lester', 'Le', ''),
('Mark', 'Ma', 'http://www.danskmoent.dk/1mark.htm'),
('Mark Dansche', 'MD', 'http://www.danskmoent.dk/1mark.htm'),
('Markestøcker', 'Ms', 'http://www.danskmoent.dk/1mark.htm'),
('Milrese', 'Mi', 'https://en.wikipedia.org/wiki/Portuguese_real'),
('Nobel', 'No', 'http://www.danskmoent.dk/1nobel.htm'),
('Nøy Daler', 'ND', ''),
('Ny Engelot', 'NE', 'http://www.danskmoent.dk/engelot.htm'),
('Ny Rosenobel', 'NR', 'http://www.danskmoent.dk/1nobel.htm'),
('Ort', 'Or', 'http://www.danskmoent.dk/ort.htm'),
('Orts daler', 'Od', 'http://www.danskmoent.dk/ort.htm'),
('Paalsk Gylden', 'Pa', 'https://en.wikipedia.org/wiki/Polish_z%C5%82oty'),
('Portugaløser', 'Po', 'http://www.danskmoent.dk/1portug.htm'),
('Prince Daler', 'PD', ''),
('Prince Gulden', 'PG', ''),
('Rhinsk Gylden', 'RG', 'http://www.danskmoent.dk/1rhingyl.htm'),
('Rigs Daler', 'RD', 'http://www.danskmoent.dk/1rbd.htm'),
('Rigs Mark', 'RM', 'http://www.danskmoent.dk/20skill.htm'),
('Rosenobel', 'Ro', 'http://www.danskmoent.dk/1nobel.htm'),
('Schots Gulden', 'Sc', ''),
('Skilling', 'Sk', 'http://www.danskmoent.dk/skilling.htm'),
('Skilling Ch.', 'SC', ''),
('Skilling D.', 'SD', ''),
('Skilling gode', 'Sg', ''),
('Skilling Lybs', 'SL', ''),
('Slet Mark', 'SM', 'http://www.danskmoent.dk/wilcke/w2a4.htm'),
('Spans Reaal', 'SR', ''),
('Støck van Achten', 'SA', 'http://www.danskmoent.dk/wilcke/w6o.htm'),
('Støcke wyn', 'Sw', ''),
('Tønder salt', 'Ts', ''),
('Ungers Gylden', 'UG', 'http://www.danskmoent.dk/1ungersk.htm');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `currency`
--
ALTER TABLE `currency`
  ADD PRIMARY KEY (`Name`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
